package com.example.gpapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TaskListActivity extends AppCompatActivity {
    private ListView taskListView;
    private DatabaseReference tasksRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);

        taskListView = findViewById(R.id.taskListView);

        if (taskListView == null) {
            throw new RuntimeException("ListView not found in activity_task_list.xml. Check the ID.");
        }

        // Establish connection to the "tasks" path in Firebase
        tasksRef = FirebaseDatabase.getInstance().getReference("tasks");

       // Fetch and display tasks from the "tasks" node in Firebase
        loadAndDisplayTasks();

        // Bottom Navigation Bar
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_tasks);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_calendar) {
                startActivity(new Intent(this, CalendarActivity.class));
                return true;
            } else if (item.getItemId() == R.id.nav_categories) {
                startActivity(new Intent(this, CategoriesActivity.class));
                return true;
            } else if (item.getItemId() == R.id.nav_tasks) {
                return true;
            }
            return false;
        });
    }

    private void loadAndDisplayTasks() {
        if (tasksRef == null) return;

        tasksRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            // Iterate through each task in the snapshot to retrieve the data
            public void onDataChange(DataSnapshot snapshot) {
                ArrayList<String> tasks = new ArrayList<>();

                for (DataSnapshot taskSnapshot : snapshot.getChildren()) {
                    String title = taskSnapshot.child("title").getValue(String.class);
                    String date = taskSnapshot.child("date").getValue(String.class);
                    String details = taskSnapshot.child("details").getValue(String.class);

                    if (title != null && date != null && details != null) {
                        String taskStr = title + "\n" + date + "\n" + details;
                        tasks.add(taskStr);
                    }
                }

                if (tasks.isEmpty()) {
                    // Display a message if no tasks are saved in Firebase
                    Toast.makeText(TaskListActivity.this, "No tasks saved in Firebase.", Toast.LENGTH_SHORT).show();
                }


                // Set up the data adapter to display the task list in the ListView
                ArrayAdapter<String> adapter = new ArrayAdapter<>(TaskListActivity.this,
                        android.R.layout.simple_list_item_1, tasks);
                taskListView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError error) {

                // Display an error message if fetching data from Firebase fails
                Toast.makeText(TaskListActivity.this, "Failed to fetch tasks: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadAndDisplayTasks();
    }
}
