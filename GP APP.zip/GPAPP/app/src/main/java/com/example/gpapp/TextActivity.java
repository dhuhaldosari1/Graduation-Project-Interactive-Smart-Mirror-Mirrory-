package com.example.gpapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;

public class TextActivity extends AppCompatActivity {
    private EditText taskName, taskDetails;
    private TextView dateTimeDisplay;
    private Button pickDateTime, saveButton, viewTasks;
    private String selectedDateTime = "";
    private DatabaseReference tasksRef;      // Firebase reference for the "tasks" path


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text);

        taskName = findViewById(R.id.taskName);
        taskDetails = findViewById(R.id.taskDetails);
        dateTimeDisplay = findViewById(R.id.dateTimeDisplay);
        pickDateTime = findViewById(R.id.pickDateTime);
        saveButton = findViewById(R.id.saveButton);
        viewTasks = findViewById(R.id.viewTasks);

        // Establish connection to the "tasks" path in Firebase
        tasksRef = FirebaseDatabase.getInstance().getReference("tasks");

        pickDateTime.setOnClickListener(view -> showDateTimePicker());

        saveButton.setOnClickListener(view -> saveTask());
        viewTasks.setOnClickListener(view -> startActivity(new Intent(this, TaskListActivity.class)));

        // Bottom Navigation Bar
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_calendar) {
                startActivity(new Intent(this, CalendarActivity.class));
            } else if (item.getItemId() == R.id.nav_categories) {
                startActivity(new Intent(this, CategoriesActivity.class));
            } else if (item.getItemId() == R.id.nav_tasks) {
                startActivity(new Intent(this, TaskListActivity.class));
            }
            return true;
        });
    }

    // Display a dialog to pick the date first, then the time, and finally show the selected date and time on the screen
    private void showDateTimePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year1, month1, dayOfMonth) -> {
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view1, hourOfDay, minute1) -> {
                selectedDateTime = String.format("%02d-%02d-%04d %02d:%02d", dayOfMonth, month1 + 1, year1, hourOfDay, minute1);
                dateTimeDisplay.setText(selectedDateTime);
            }, hour, minute, true);
            timePickerDialog.show();
        }, year, month, day);
        datePickerDialog.show();
    }

    private void saveTask() {
        String name = taskName.getText().toString();
        String details = taskDetails.getText().toString();

        if (name.isEmpty() || details.isEmpty() || selectedDateTime.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save the task to Firebase
        if (tasksRef != null) {
            HashMap<String, String> task = new HashMap<>();
            task.put("title", name);
            task.put("date", selectedDateTime);
            task.put("details", details);

            tasksRef.push().setValue(task)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(TextActivity.this, "Task synced with Firebase & MagicMirror", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(TextActivity.this, "Failed to sync: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }
}
