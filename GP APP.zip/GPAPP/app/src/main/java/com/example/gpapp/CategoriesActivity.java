package com.example.gpapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class CategoriesActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);

       // Configure buttons to navigate to other activities
        button1.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, VoiceActivity.class);
            startActivity(intent);
        });

        button2.setOnClickListener(v -> {
            Intent intent = new Intent(CategoriesActivity.this, TextActivity.class);
            startActivity(intent);
        });

        //  Bottom Navigation Bar
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Set the default selected item when the page opens
        bottomNavigationView.setSelectedItemId(R.id.nav_categories);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_calendar) {
                startActivity(new Intent(this, CalendarActivity.class));
                return true;
            } else if (item.getItemId() == R.id.nav_categories) {
                return true;
            } else if (item.getItemId() == R.id.nav_tasks) {
                startActivity(new Intent(this, TaskListActivity.class));
                return true;
            }
            return false;
        });
    }
}
