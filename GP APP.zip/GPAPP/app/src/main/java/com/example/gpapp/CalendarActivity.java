package com.example.gpapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CalendarActivity extends AppCompatActivity {
    private CalendarView calendarView;
    private Button categoriesBtn;
    private TextView currentTime;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        // Linking elements
        calendarView = findViewById(R.id.calendarView);
        categoriesBtn = findViewById(R.id.categoriesBtn);
        currentTime = findViewById(R.id.currentTime);
        calendar = Calendar.getInstance();

        // Set today's date as default in CalendarView
        calendarView.setDate(calendar.getTimeInMillis(), false, true);

        // Configure the button to navigate to the Categories page
        categoriesBtn.setOnClickListener(v -> {
            startActivity(new Intent(CalendarActivity.this, CategoriesActivity.class));
        });

        // Continuously update the displayed time in the TextView
        final Handler handler = new Handler();
        Runnable timeRunnable = new Runnable() {
            @Override
            public void run() {
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                String time = sdf.format(Calendar.getInstance().getTime());
                currentTime.setText(time);
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(timeRunnable);

        //  Bottom Navigation Bar
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Set the default selected item when the page opens
        bottomNavigationView.setSelectedItemId(R.id.nav_calendar);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_calendar) {
                return true;
            } else if (item.getItemId() == R.id.nav_categories) {
                startActivity(new Intent(this, CategoriesActivity.class));
                return true;
            } else if (item.getItemId() == R.id.nav_tasks) {
                startActivity(new Intent(this, TaskListActivity.class));
                return true;
            }
            return false;
        });
    }
}

