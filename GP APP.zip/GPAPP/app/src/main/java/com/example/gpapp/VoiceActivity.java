package com.example.gpapp;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.Locale;

public class VoiceActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_VOICE = 1;
    private TextView txtTask, txtDate, txtTime;
    private String taskName = "", taskDetails = "", taskDate = "", taskTime = "";
    private int voiceStep = 0;

    private DatabaseReference mirrorRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice);

        Button btnVoiceInput = findViewById(R.id.btnVoiceInput);
        Button btnSaveTask = findViewById(R.id.btnSaveTask);
        txtTask = findViewById(R.id.txtTask);
        txtDate = findViewById(R.id.txtDate);
        txtTime = findViewById(R.id.txtTime);

        mirrorRef = FirebaseDatabase.getInstance().getReference("tasks");

        btnVoiceInput.setOnClickListener(v -> {
            voiceStep = 0;
            startVoiceRecognition("Say the task name");
        });

        btnSaveTask.setOnClickListener(v -> saveTask());

        // Bottom Navigation Bar
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_calendar) {
                startActivity(new Intent(this, CalendarActivity.class));
                return true;
            } else if (item.getItemId() == R.id.nav_categories) {
                startActivity(new Intent(this, CategoriesActivity.class));
                return true;
            } else if (item.getItemId() == R.id.nav_tasks) {
                startActivity(new Intent(this, TaskListActivity.class));
                return true;
            }
            return false;
        });
    }
// Activate listening to voice and convert it to text
    private void startVoiceRecognition(String prompt) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, prompt);
        try {
            startActivityForResult(intent, REQUEST_CODE_VOICE);
        } catch (Exception e) {
            Toast.makeText(this, "Your device does not support speech input", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_VOICE && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (result != null && !result.isEmpty()) {
                String spokenText = result.get(0);
                processVoiceInput(spokenText);
            }
        }
    }
    // Process the received speech recognition text and update the fields
    private void processVoiceInput(String spokenText) {
        switch (voiceStep) {
            case 0:
                taskName = spokenText;
                txtTask.setText("Task Name: " + taskName);
                voiceStep++;
                startVoiceRecognition("Say the task details");
                break;
            case 1:
                taskDetails = spokenText;
                txtDate.setText("Task Details: " + taskDetails);
                voiceStep++;
                startVoiceRecognition("Say the task date");
                break;
            case 2:
                taskDate = spokenText;
                txtTime.setText("Date: " + taskDate);
                voiceStep++;
                startVoiceRecognition("Say the task time");
                break;
            case 3:
                taskTime = spokenText;
                txtTime.setText("Time: " + taskTime);
                Toast.makeText(this, "All details recorded! Click Save Task.", Toast.LENGTH_SHORT).show();
                voiceStep = 0;
                break;
        }
    }

    private void saveTask() {
        if (taskName.isEmpty() || taskDetails.isEmpty() || taskDate.isEmpty() || taskTime.isEmpty()) {
            Toast.makeText(this, "Please enter all details using voice", Toast.LENGTH_SHORT).show();
            return;
        }

        String fullDateTime = taskDate + " " + taskTime;

        // Save the task to Firebase
        if (mirrorRef != null) {
            Task task = new Task(taskName, taskDetails, fullDateTime);
            String taskId = mirrorRef.push().getKey();
            mirrorRef.child(taskId).setValue(task)
                    .addOnSuccessListener(aVoid -> Toast.makeText(this, "Task Saved Successfully to Firebase", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to sync with Firebase: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }

        Toast.makeText(this, "Task saved successfully!", Toast.LENGTH_SHORT).show();
    }
}
