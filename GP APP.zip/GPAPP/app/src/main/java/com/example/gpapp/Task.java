package com.example.gpapp;

public class Task {
    private String title;
    private String details;
    private String date;

    // Constructor
    public Task(String title, String details, String date) {
        this.title = title;
        this.details = details;
        this.date = date;  // date includes both date and time
    }

    // Default constructor for Firebase
    public Task() {
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
